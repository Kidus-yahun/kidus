// Initialize Lucide icons
document.addEventListener('DOMContentLoaded', function() {
    lucide.createIcons();
    
    // Initialize the application
    initializeApp();
});

function initializeApp() {
    // Elements
    const landingPage = document.getElementById('landing-page');
    const loginPage = document.getElementById('login-page');
    const mainApp = document.getElementById('main-app');
    const startPracticeBtn = document.getElementById('start-practice-btn');
    const loginForm = document.querySelector('#login-form form');
    const signupForm = document.querySelector('#signup-form form');
    const logoutBtn = document.getElementById('logout-btn');
    
    // Start Practice button - transition to login page
    startPracticeBtn.addEventListener('click', function() {
        showLoginPage();
    });
    
    // Tab functionality for login/signup
    initializeTabs();
    
    // Dashboard tabs
    initializeDashboardTabs();
    
    // Mobile navigation
    initializeMobileNav();
    
    // Form submissions
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        login();
    });
    
    signupForm.addEventListener('submit', function(e) {
        e.preventDefault();
        login(); // For demo purposes, signup also logs in
    });
    
    // Logout functionality
    logoutBtn.addEventListener('click', function() {
        logout();
    });
    
    // Practice exam buttons
    initializePracticeButtons();
    
    // View buttons
    initializeViewButtons();
}

function showLoginPage() {
    const landingPage = document.getElementById('landing-page');
    const loginPage = document.getElementById('login-page');
    
    // Add fade out animation to landing page
    landingPage.style.opacity = '0';
    landingPage.style.transform = 'scale(0.95)';
    landingPage.style.transition = 'all 0.3s ease-out';
    
    setTimeout(() => {
        landingPage.classList.add('hidden');
        loginPage.classList.remove('hidden');
        loginPage.classList.add('fade-in');
        
        // Reinitialize icons for the login page
        lucide.createIcons();
    }, 300);
}

function initializeTabs() {
    const tabTriggers = document.querySelectorAll('.tab-trigger');
    const tabContents = document.querySelectorAll('#login-page .tab-content');
    
    tabTriggers.forEach(trigger => {
        trigger.addEventListener('click', function() {
            const targetTab = this.getAttribute('data-tab');
            
            // Remove active classes
            tabTriggers.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active classes
            this.classList.add('active');
            document.getElementById(targetTab + '-form').classList.add('active');
        });
    });
}

function initializeDashboardTabs() {
    const dashboardTabs = document.querySelectorAll('.dashboard-tab');
    const tabContents = document.querySelectorAll('#main-app .tab-content');
    
    dashboardTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetContent = this.getAttribute('data-content');
            
            // Remove active classes
            dashboardTabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active classes
            this.classList.add('active');
            const targetElement = document.getElementById(targetContent + '-content');
            if (targetElement) {
                targetElement.classList.add('active');
                targetElement.classList.add('fade-in');
            }
        });
    });
}

function initializeMobileNav() {
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');
    
    mobileNavLinks.forEach(link => {
        link.addEventListener('click', function() {
            const section = this.getAttribute('data-section');
            console.log('Mobile navigation:', section);
            // Add mobile navigation logic here
        });
    });
    
    // Toggle mobile nav on small screens
    const navLinks = document.querySelector('.nav-links');
    const mobileNav = document.querySelector('.mobile-nav');
    
    function checkMobileNav() {
        if (window.innerWidth <= 768) {
            navLinks.style.display = 'none';
            mobileNav.classList.remove('hidden');
        } else {
            navLinks.style.display = 'flex';
            mobileNav.classList.add('hidden');
        }
    }
    
    window.addEventListener('resize', checkMobileNav);
    checkMobileNav(); // Initial check
}

function initializePracticeButtons() {
    const practiceButtons = document.querySelectorAll('.btn-practice');
    
    practiceButtons.forEach(button => {
        button.addEventListener('click', function() {
            const card = this.closest('.practice-card');
            const subject = card.querySelector('h3').textContent;
            
            // Add loading state
            const originalText = this.textContent;
            this.textContent = 'Starting...';
            this.disabled = true;
            
            // Simulate loading
            setTimeout(() => {
                this.textContent = originalText;
                this.disabled = false;
                showNotification(`Starting ${subject} practice exam!`, 'success');
            }, 1000);
        });
    });
}

function initializeViewButtons() {
    const viewButtons = document.querySelectorAll('.btn-view');
    
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const card = this.closest('.subject-card, .grade-card');
            const title = card.querySelector('h3').textContent;
            
            showNotification(`Opening ${title} content...`, 'info');
        });
    });
}

function login() {
    const loginPage = document.getElementById('login-page');
    const mainApp = document.getElementById('main-app');
    
    // Add fade out animation to login page
    loginPage.style.opacity = '0';
    loginPage.style.transform = 'scale(0.95)';
    loginPage.style.transition = 'all 0.3s ease-out';
    
    setTimeout(() => {
        loginPage.classList.add('hidden');
        mainApp.classList.remove('hidden');
        mainApp.classList.add('fade-in');
        
        // Reinitialize icons for the main app
        lucide.createIcons();
        
        showNotification('Welcome to EthioMatrix!', 'success');
    }, 300);
}

function logout() {
    const landingPage = document.getElementById('landing-page');
    const loginPage = document.getElementById('login-page');
    const mainApp = document.getElementById('main-app');
    
    // Reset landing page styles
    landingPage.style.opacity = '';
    landingPage.style.transform = '';
    landingPage.style.transition = '';
    
    // Reset login page styles
    loginPage.style.opacity = '';
    loginPage.style.transform = '';
    loginPage.style.transition = '';
    
    mainApp.classList.add('hidden');
    loginPage.classList.add('hidden');
    landingPage.classList.remove('hidden');
    
    // Reset forms
    document.querySelectorAll('form').forEach(form => form.reset());
    
    // Reset tabs to default
    document.querySelectorAll('.tab-trigger').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    document.querySelector('.tab-trigger[data-tab="login"]').classList.add('active');
    document.getElementById('login-form').classList.add('active');
    
    // Reset dashboard tabs
    document.querySelectorAll('.dashboard-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('#main-app .tab-content').forEach(c => c.classList.remove('active'));
    document.querySelector('.dashboard-tab[data-content="practice"]').classList.add('active');
    document.getElementById('practice-content').classList.add('active');
    
    // Reinitialize icons
    lucide.createIcons();
    
    showNotification('Logged out successfully', 'info');
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? 'var(--green-light)' : type === 'error' ? 'var(--red-light)' : 'var(--blue-light)'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-lg);
        z-index: 1000;
        transform: translateX(100%);
        transition: transform 0.3s ease-out;
        font-weight: 500;
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add some interactive features
function addInteractiveFeatures() {
    // Add hover effects to cards
    const cards = document.querySelectorAll('.practice-card, .subject-card, .grade-card, .stat-card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-4px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
}

// Initialize interactive features when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(addInteractiveFeatures, 500);
});

// Add progress animation
function animateProgress() {
    const progressBars = document.querySelectorAll('.progress-fill');
    
    progressBars.forEach(bar => {
        const width = bar.style.width;
        bar.style.width = '0%';
        
        setTimeout(() => {
            bar.style.width = width;
        }, 500);
    });
}

// Animate progress bars when practice tab is shown
document.addEventListener('DOMContentLoaded', function() {
    const practiceTab = document.querySelector('.dashboard-tab[data-content="practice"]');
    
    if (practiceTab) {
        practiceTab.addEventListener('click', function() {
            setTimeout(animateProgress, 200);
        });
    }
    
    // Initial animation
    setTimeout(animateProgress, 1000);
});

// Add keyboard navigation
document.addEventListener('keydown', function(e) {
    // ESC key to go back to login (for demo purposes)
    if (e.key === 'Escape' && !document.getElementById('login-page').classList.contains('hidden')) {
        // Already on login page, do nothing
    }
    
    // Tab navigation enhancement
    if (e.key === 'Tab') {
        // Enhance tab navigation - could add more sophisticated logic here
    }
});

// Add search functionality (placeholder)
function addSearchFunctionality() {
    // This could be expanded to search through subjects, notes, etc.
    const searchInputs = document.querySelectorAll('input[type="search"]');
    
    searchInputs.forEach(input => {
        input.addEventListener('input', function() {
            const query = this.value.toLowerCase();
            // Add search logic here
            console.log('Searching for:', query);
        });
    });
}

// Performance optimization - lazy load content
function setupLazyLoading() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    });
    
    const lazyElements = document.querySelectorAll('.stat-card, .analytics-card');
    lazyElements.forEach(el => observer.observe(el));
}

// Initialize additional features
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        addSearchFunctionality();
        setupLazyLoading();
    }, 1000);
});