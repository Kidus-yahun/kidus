import { GraduationCap, BookOpen, FileText, Brain, StickyNote, ChartLine, Target, Rocket, Heart, Star, Users, TrendingUp, Award, Zap, Shield, Clock } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-yellow-50 to-red-50 overflow-y-auto">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="text-center py-16 px-4 mb-16">
          <div className="flex flex-col items-center gap-4 mb-8 animate-fade-in">
            <div className="w-24 h-24 bg-gradient-to-br from-green-500 via-yellow-500 to-red-500 rounded-2xl flex items-center justify-center shadow-2xl transform hover:scale-105 transition-transform">
              <GraduationCap className="w-14 h-14 text-white" />
            </div>
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 bg-clip-text text-transparent leading-tight">
              EthioMatrix
            </h1>
          </div>
          <p className="text-2xl md:text-3xl text-gray-700 font-semibold mb-6">
            Your Gateway to Grade 12 Excellence
          </p>
          <p className="text-lg md:text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed mb-8">
            Every great journey begins with a single step. Today, you're taking yours towards academic excellence and a brighter future for Ethiopia.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <button
              onClick={onGetStarted}
              className="inline-flex items-center gap-3 bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 text-white px-10 py-5 rounded-xl text-lg font-bold shadow-2xl hover:shadow-3xl hover:-translate-y-1 transition-all transform"
            >
              <Rocket className="w-6 h-6" />
              Start Your Journey
            </button>
            <div className="flex items-center gap-2 text-gray-600">
              <Users className="w-5 h-5 text-green-500" />
              <span className="font-medium">Join 50,000+ Ethiopian students</span>
            </div>
          </div>
        </div>

        {/* Emotional/Motivational Quote Section */}
        <div className="bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 rounded-3xl p-1 mb-16 mx-4">
          <div className="bg-white rounded-3xl p-8 md:p-12 text-center">
            <Heart className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <blockquote className="text-2xl md:text-3xl font-semibold text-gray-800 mb-4 italic">
              "Education is the most powerful weapon which you can use to change the world"
            </blockquote>
            <p className="text-lg text-gray-600">- Nelson Mandela</p>
            <p className="text-base text-gray-500 mt-6 max-w-3xl mx-auto leading-relaxed">
              Your dreams of becoming a doctor, engineer, scientist, or leader start here. EthioMatrix is more than just a study platform—it's your partner in building the future you deserve.
            </p>
          </div>
        </div>

        {/* Statistics Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16 px-4">
          <div className="bg-white rounded-2xl p-6 text-center shadow-lg border-l-4 border-green-500 hover:shadow-xl transition-shadow">
            <div className="text-4xl font-bold text-green-500 mb-2">50,000+</div>
            <p className="text-gray-600 font-medium">Active Students</p>
          </div>
          <div className="bg-white rounded-2xl p-6 text-center shadow-lg border-l-4 border-yellow-500 hover:shadow-xl transition-shadow">
            <div className="text-4xl font-bold text-yellow-500 mb-2">500+</div>
            <p className="text-gray-600 font-medium">Practice Exams</p>
          </div>
          <div className="bg-white rounded-2xl p-6 text-center shadow-lg border-l-4 border-red-500 hover:shadow-xl transition-shadow">
            <div className="text-4xl font-bold text-red-500 mb-2">95%</div>
            <p className="text-gray-600 font-medium">Success Rate</p>
          </div>
          <div className="bg-white rounded-2xl p-6 text-center shadow-lg border-l-4 border-blue-500 hover:shadow-xl transition-shadow">
            <div className="text-4xl font-bold text-blue-500 mb-2">1000+</div>
            <p className="text-gray-600 font-medium">Study Materials</p>
          </div>
        </div>

        {/* Emotional Story Section */}
        <div className="bg-white rounded-3xl p-8 md:p-12 mb-16 mx-4 shadow-xl">
          <div className="text-center mb-8">
            <Star className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Your Story Starts Here
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
              We believe in you. We believe in your potential to achieve greatness. We believe that every Ethiopian student deserves access to quality education that can transform their life and their community.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Dream Big</h3>
              <p className="text-gray-600">
                Your aspirations matter. Whether you dream of medical school, engineering, or any other field, we're here to help you reach it.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-yellow-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Study Smart</h3>
              <p className="text-gray-600">
                Access world-class materials designed specifically for Ethiopian students. Learn at your own pace, anytime, anywhere.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Achieve Excellence</h3>
              <p className="text-gray-600">
                Join thousands of successful students who have transformed their lives through dedication and the right resources.
              </p>
            </div>
          </div>
        </div>

        {/* Why Choose Us Section */}
        <div className="mb-16 px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Everything You Need to Succeed
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We've built a comprehensive platform with your success in mind. Every feature is designed to help you achieve your academic goals.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl p-8 shadow-md border-l-4 border-green-500 hover:shadow-xl hover:-translate-y-2 transition-all">
              <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                <BookOpen className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Comprehensive Textbooks
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Access complete textbooks for Natural and Social Science streams covering all Grade 12 subjects. Every chapter, every concept, right at your fingertips.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-md border-l-4 border-yellow-500 hover:shadow-xl hover:-translate-y-2 transition-all">
              <div className="w-14 h-14 bg-yellow-100 rounded-xl flex items-center justify-center mb-4">
                <FileText className="w-8 h-8 text-yellow-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Past Exam Papers
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Practice with previous years' examination papers across all subjects. Learn from the past to excel in your future exams.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-md border-l-4 border-red-500 hover:shadow-xl hover:-translate-y-2 transition-all">
              <div className="w-14 h-14 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <Brain className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Interactive Practice Exams
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Take realistic practice exams, receive instant feedback, and track your progress. Build confidence before the real test.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-md border-l-4 border-blue-500 hover:shadow-xl hover:-translate-y-2 transition-all">
              <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                <StickyNote className="w-8 h-8 text-blue-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Quick Reference Notes
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Short, focused notes covering key concepts for Grades 9-12. Perfect for quick revision and last-minute preparation.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-md border-l-4 border-green-500 hover:shadow-xl hover:-translate-y-2 transition-all">
              <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                <ChartLine className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Detailed Progress Tracking
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Monitor your performance with powerful analytics. See your strengths, identify weaknesses, and focus your study time wisely.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-md border-l-4 border-red-500 hover:shadow-xl hover:-translate-y-2 transition-all">
              <div className="w-14 h-14 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <Target className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Complete Exam Preparation
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Everything you need for university entrance exams and Grade 12 finals. Your path to success starts here.
              </p>
            </div>
          </div>
        </div>

        {/* Student Testimonials */}
        <div className="bg-white rounded-3xl p-8 md:p-12 mb-16 mx-4 shadow-xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Real Stories, Real Success
            </h2>
            <p className="text-lg text-gray-600">
              Hear from students who transformed their academic journey with EthioMatrix
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-6 border-2 border-green-200">
              <div className="flex items-center gap-1 mb-4">
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
              </div>
              <p className="text-gray-700 italic mb-4">
                "EthioMatrix changed my life! I improved my scores by 30% and got accepted to my dream university. The practice exams were exactly what I needed."
              </p>
              <div>
                <p className="font-semibold text-gray-900">Abeba T.</p>
                <p className="text-sm text-gray-600">Medical Student, Addis Ababa University</p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-2xl p-6 border-2 border-yellow-200">
              <div className="flex items-center gap-1 mb-4">
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
              </div>
              <p className="text-gray-700 italic mb-4">
                "The best study resource for Ethiopian students! I was struggling with Physics and Math, but the detailed materials and practice tests helped me excel."
              </p>
              <div>
                <p className="font-semibold text-gray-900">Daniel K.</p>
                <p className="text-sm text-gray-600">Engineering Student, Bahir Dar University</p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-2xl p-6 border-2 border-red-200">
              <div className="flex items-center gap-1 mb-4">
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
                <Star className="w-5 h-5 text-yellow-500 fill-current" />
              </div>
              <p className="text-gray-700 italic mb-4">
                "I wish I had found EthioMatrix earlier! The progress tracking kept me motivated and the study materials are top quality. Highly recommended!"
              </p>
              <div>
                <p className="font-semibold text-gray-900">Rahel M.</p>
                <p className="text-sm text-gray-600">Business Student, Jimma University</p>
              </div>
            </div>
          </div>
        </div>

        {/* Benefits Section */}
        <div className="bg-gradient-to-br from-green-500 via-yellow-500 to-red-500 rounded-3xl p-1 mb-16 mx-4">
          <div className="bg-white rounded-3xl p-8 md:p-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 text-center mb-12">
              Why Students Love EthioMatrix
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Clock className="w-6 h-6 text-green-500" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Study Anytime, Anywhere</h3>
                  <p className="text-gray-600">
                    Access all materials 24/7 from your phone, tablet, or computer. Study at your own pace, on your own schedule.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <Shield className="w-6 h-6 text-yellow-500" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Trusted by Thousands</h3>
                  <p className="text-gray-600">
                    Join over 50,000 Ethiopian students who trust EthioMatrix for their Grade 12 preparation.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <Award className="w-6 h-6 text-red-500" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Proven Results</h3>
                  <p className="text-gray-600">
                    95% of our students report improved grades and increased confidence in their exam preparation.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Heart className="w-6 h-6 text-blue-500" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Made with Love for Ethiopia</h3>
                  <p className="text-gray-600">
                    Created specifically for Ethiopian students, aligned with your curriculum and exam requirements.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Final Motivational Section */}
        <div className="bg-white rounded-3xl p-8 md:p-12 mb-16 mx-4 shadow-xl text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
            The Future Belongs to Those Who <br />
            <span className="bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 bg-clip-text text-transparent">
              Prepare for It Today
            </span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto mb-8 leading-relaxed">
            You have the power to shape your destiny. Every hour you invest in your education brings you closer to your dreams. Your family, your community, and your country are counting on you. But most importantly, you owe it to yourself to unlock your full potential.
          </p>
          <p className="text-base md:text-lg text-gray-700 max-w-2xl mx-auto mb-10 font-medium italic">
            Remember: Success is not an accident. It's a choice. It's practice, preparation, and persistence. And it starts right here, right now.
          </p>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 rounded-3xl p-1 mb-16 mx-4">
          <div className="bg-white rounded-3xl p-8 md:p-16 text-center">
            <Rocket className="w-16 h-16 mx-auto mb-6 text-green-500" />
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Your Journey to Excellence Starts Now
            </h2>
            <p className="text-lg md:text-xl text-gray-600 mb-4 max-w-2xl mx-auto">
              Join thousands of Ethiopian students who are already on their path to success
            </p>
            <p className="text-base text-gray-500 mb-10 max-w-xl mx-auto">
              Free access to all study materials, practice exams, and progress tracking tools
            </p>
            <button
              onClick={onGetStarted}
              className="inline-flex items-center gap-3 bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 text-white px-12 py-6 rounded-xl text-xl font-bold shadow-2xl hover:shadow-3xl hover:-translate-y-1 transition-all transform mb-6"
            >
              <Rocket className="w-7 h-7" />
              Begin Your Journey to Success
            </button>
            <p className="text-sm text-gray-500">
              No credit card required • Instant access • 50,000+ students already learning
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center py-12 px-4 mb-8">
          <div className="max-w-3xl mx-auto">
            <div className="flex flex-col items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 via-yellow-500 to-red-500 rounded-xl flex items-center justify-center">
                <GraduationCap className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 bg-clip-text text-transparent">
                EthioMatrix
              </h3>
            </div>
            <p className="text-gray-600 mb-4">
              Empowering Ethiopian students for academic success
            </p>
            <p className="text-gray-500 text-sm">
              Building a brighter future for Ethiopia, one student at a time. 🇪🇹
            </p>
            <div className="mt-8 pt-8 border-t border-gray-200">
              <p className="text-gray-400 text-sm">
                © 2025 EthioMatrix. Made with ❤️ for Ethiopian Students
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
