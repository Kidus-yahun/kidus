import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, LineChart, Line, PieChart, Pie, Tooltip, Legend } from 'recharts';
import { Clock, Calendar, TrendingDown, Trophy, AlertTriangle, BookOpen, Target, Award, Flame, FileText, TrendingUp, Brain, CheckCircle } from 'lucide-react';

export function AnalyticsPanel() {
  // Complete analytics data matching the design
  const overallProgress = {
    averageScore: 86,
    examsCompleted: 33,
    studyTime: 72
  };

  const weakAreas = [
    { subject: 'Physics - Electricity', score: 62 },
    { subject: 'Math - Calculus', score: 68 },
    { subject: 'English - Writing', score: 74 }
  ];

  const practiceExams = 33;
  const avgScore = 87;
  const studyTimeMonth = 72;
  const studyStreak = 12;
  const shortNotes = 242;

  // Detailed subject breakdown
  const subjectScores = [
    { subject: 'Math', score: 92, color: '#16a34a' },
    { subject: 'English', score: 85, color: '#2563eb' },
    { subject: 'Physics', score: 78, color: '#dc2626' },
    { subject: 'Chemistry', score: 88, color: '#7c3aed' },
    { subject: 'Biology', score: 91, color: '#f59e0b' },
    { subject: 'History', score: 83, color: '#ec4899' }
  ];

  const recentAttempts = [
    { exam: 'Mathematics Practice Test 3', date: '2024-10-20', score: 94, subject: 'Mathematics' },
    { exam: 'English Literature Quiz', date: '2024-10-19', score: 87, subject: 'English' },
    { exam: 'Physics Mechanics Exam', date: '2024-10-18', score: 76, subject: 'Physics' },
    { exam: 'Biology Cell Structure Test', date: '2024-10-17', score: 91, subject: 'Biology' },
    { exam: 'Chemistry Organic Quiz', date: '2024-10-16', score: 89, subject: 'Chemistry' },
    { exam: 'History Ethiopian Empire', date: '2024-10-15', score: 85, subject: 'History' }
  ];

  // Weekly progress data
  const weeklyProgress = [
    { day: 'Mon', score: 82, time: 8 },
    { day: 'Tue', score: 85, time: 10 },
    { day: 'Wed', score: 88, time: 12 },
    { day: 'Thu', score: 84, time: 9 },
    { day: 'Fri', score: 90, time: 14 },
    { day: 'Sat', score: 87, time: 11 },
    { day: 'Sun', score: 86, time: 8 }
  ];

  // Time distribution by subject
  const timeDistribution = [
    { name: 'Math', value: 25, color: '#16a34a' },
    { name: 'Physics', value: 20, color: '#dc2626' },
    { name: 'Chemistry', value: 18, color: '#7c3aed' },
    { name: 'Biology', value: 15, color: '#f59e0b' },
    { name: 'English', value: 12, color: '#2563eb' },
    { name: 'History', value: 10, color: '#ec4899' }
  ];

  // Monthly exam completion trend
  const monthlyTrend = [
    { month: 'Jun', exams: 18 },
    { month: 'Jul', exams: 22 },
    { month: 'Aug', exams: 27 },
    { month: 'Sep', exams: 30 },
    { month: 'Oct', exams: 33 }
  ];

  const totalTimeSpent = studyTimeMonth;
  const totalExamsCompleted = practiceExams;
  const overallAverage = avgScore;

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-green-600 dark:text-green-400';
    if (score >= 70) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getScoreBadgeColor = (score: number) => {
    if (score >= 85) return 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300';
    if (score >= 70) return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300';
    return 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300';
  };

  return (
    <div className="space-y-6">
      {/* Main Title */}
      <h2 className="text-2xl">Your Performance Analytics</h2>

      {/* Overall Progress and Weak Areas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Overall Progress */}
        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle>Overall Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-3xl text-green-600 dark:text-green-400">{overallProgress.averageScore}%</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Average Score</p>
              </div>
              <div className="text-center">
                <p className="text-3xl text-gray-900 dark:text-gray-100">{overallProgress.examsCompleted}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Exams Completed</p>
              </div>
              <div className="text-center">
                <p className="text-3xl text-green-600 dark:text-green-400">{overallProgress.studyTime}h</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Study Time</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Weak Areas */}
        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle>Weak Areas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {weakAreas.map((area, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-gray-700 dark:text-gray-300">{area.subject}</span>
                  <span className="text-red-600 dark:text-red-400">{area.score}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Stat Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-l-4 border-green-500 dark:bg-gray-800">
          <CardContent className="pt-6">
            <div>
              <p className="text-3xl text-green-600 dark:text-green-400">{practiceExams}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Practice Exams</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">Completed this month</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-blue-500 dark:bg-gray-800">
          <CardContent className="pt-6">
            <div>
              <p className="text-3xl text-blue-600 dark:text-blue-400">{avgScore}%</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Avg Score</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">Across all subjects</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-yellow-500 dark:bg-gray-800">
          <CardContent className="pt-6">
            <div>
              <p className="text-3xl text-yellow-600 dark:text-yellow-400">{studyTimeMonth}h</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Study Time</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">This month</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-red-500 dark:bg-gray-800">
          <CardContent className="pt-6">
            <div>
              <p className="text-3xl text-red-600 dark:text-red-400">{studyStreak}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Study Streak</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">Days in a row</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Short Notes Card */}
      <Card className="border-l-4 border-purple-500 dark:bg-gray-800">
        <CardContent className="pt-6">
          <div>
            <p className="text-3xl text-purple-600 dark:text-purple-400">{shortNotes}</p>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Short Notes</p>
            <p className="text-xs text-gray-500 dark:text-gray-500">Available notes</p>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Analytics Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject Performance Chart */}
        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5" />
              Average Score by Subject
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={subjectScores}>
                  <XAxis dataKey="subject" />
                  <YAxis domain={[0, 100]} />
                  <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                    {subjectScores.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 space-y-2">
              {subjectScores.map((subject) => (
                <div key={subject.subject} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: subject.color }}
                    ></div>
                    <span className="text-sm font-medium">{subject.subject}</span>
                  </div>
                  <Badge className={getScoreBadgeColor(subject.score)}>
                    {subject.score}%
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Weekly Progress Trend */}
        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Weekly Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyProgress}>
                  <XAxis dataKey="day" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    stroke="#16a34a" 
                    strokeWidth={2}
                    dot={{ fill: '#16a34a', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="p-3 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600">Best Day</p>
                <p className="text-xl text-green-600">Friday - 90%</p>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600">Avg This Week</p>
                <p className="text-xl text-blue-600">86%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Attempts and Time Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Exam Attempts */}
        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Recent Exam Attempts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentAttempts.map((attempt, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg border hover:bg-gray-50">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{attempt.exam}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-xs text-gray-500">{attempt.date}</p>
                      <Badge variant="outline" className="text-xs">
                        {attempt.subject}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right ml-4">
                    <p className={`text-sm ${getScoreColor(attempt.score)}`}>
                      {attempt.score}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Time Distribution */}
        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Study Time Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={timeDistribution}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label
                  >
                    {timeDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2">
              {timeDistribution.map((item) => (
                <div key={item.name} className="flex items-center gap-1">
                  <div 
                    className="w-2 h-2 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-xs text-gray-600">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Trend */}
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Monthly Exam Completion Trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyTrend}>
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="exams" fill="#16a34a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Growth Rate</p>
                <p className="text-xl text-green-600">+83%</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">From June to October</p>
                <p className="text-xl text-gray-900">18 → 33 exams</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Areas for Improvement */}
      <Card className="border-orange-200 dark:bg-gray-800">
        <CardHeader className="bg-orange-50 rounded-t-lg">
          <CardTitle className="flex items-center gap-2 text-orange-800">
            <AlertTriangle className="w-5 h-5" />
            Detailed Areas for Improvement
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {[
              { subject: 'Physics', area: 'Electricity', score: 62, improvement: '+8%', topics: ['Ohm\'s Law', 'Circuit Analysis', 'Capacitors'] },
              { subject: 'Mathematics', area: 'Calculus', score: 68, improvement: '+5%', topics: ['Derivatives', 'Integration', 'Limits'] },
              { subject: 'English', area: 'Writing', score: 74, improvement: '+12%', topics: ['Essay Structure', 'Grammar', 'Vocabulary'] }
            ].map((area, index) => (
              <div key={index} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p className="font-medium text-gray-900">{area.subject} - {area.area}</p>
                    <p className="text-sm text-gray-600">Current Score: {area.score}%</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">
                    {area.improvement} improvement
                  </Badge>
                </div>
                <div className="space-y-1 mb-3">
                  <div className="flex justify-between text-sm">
                    <span>Progress to 85% target</span>
                    <span>{Math.round(((area.score - 50) / (85 - 50)) * 100)}%</span>
                  </div>
                  <Progress 
                    value={((area.score - 50) / (85 - 50)) * 100} 
                    className="h-2 bg-gray-200"
                  />
                </div>
                <div className="flex flex-wrap gap-2">
                  {area.topics.map((topic, i) => (
                    <Badge key={i} variant="outline" className="text-xs">
                      {topic}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border border-blue-200">
            <h4 className="font-medium text-gray-900 mb-2">💡 Personalized Study Recommendations</h4>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• Focus 30 minutes daily on Physics electricity concepts - Practice circuit problems</li>
              <li>• Practice 5 calculus problems daily - Focus on derivative applications</li>
              <li>• Write one essay per week to improve English writing skills</li>
              <li>• Review weak topics before practice exams for better results</li>
              <li>• Maintain your study streak - You're doing great! 🔥</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Achievement Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200 dark:bg-gray-800">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Trophy className="w-6 h-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Top Performer</p>
                <p className="font-medium">Mathematics</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 dark:bg-gray-800">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Flame className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Best Streak</p>
                <p className="font-medium">{studyStreak} Days</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 dark:bg-gray-800">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Award className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Most Improved</p>
                <p className="font-medium">English (+12%)</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}