import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Play, Clock, Trophy, Target } from 'lucide-react';

interface PracticeExamCardProps {
  title: string;
  description: string;
  totalExams: number;
  completedExams: number;
  averageScore: number;
  timeSpent: string;
  color: 'green' | 'yellow' | 'red' | 'blue';
  onStartPractice: () => void;
}

export function PracticeExamCard({ 
  title, 
  description, 
  totalExams, 
  completedExams, 
  averageScore, 
  timeSpent, 
  color, 
  onStartPractice 
}: PracticeExamCardProps) {
  const colorClasses = {
    green: {
      border: 'border-green-200 dark:border-green-800',
      headerBg: 'bg-green-50 dark:bg-green-900/30',
      icon: 'text-green-600 dark:text-green-400',
      button: 'bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600',
      badge: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300',
      progress: 'bg-green-600 dark:bg-green-500'
    },
    yellow: {
      border: 'border-yellow-200 dark:border-yellow-800',
      headerBg: 'bg-yellow-50 dark:bg-yellow-900/30',
      icon: 'text-yellow-600 dark:text-yellow-400',
      button: 'bg-yellow-600 hover:bg-yellow-700 dark:bg-yellow-700 dark:hover:bg-yellow-600',
      badge: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300',
      progress: 'bg-yellow-600 dark:bg-yellow-500'
    },
    red: {
      border: 'border-red-200 dark:border-red-800',
      headerBg: 'bg-red-50 dark:bg-red-900/30',
      icon: 'text-red-600 dark:text-red-400',
      button: 'bg-red-600 hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600',
      badge: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300',
      progress: 'bg-red-600 dark:bg-red-500'
    },
    blue: {
      border: 'border-blue-200 dark:border-blue-800',
      headerBg: 'bg-blue-50 dark:bg-blue-900/30',
      icon: 'text-blue-600 dark:text-blue-400',
      button: 'bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600',
      badge: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300',
      progress: 'bg-blue-600 dark:bg-blue-500'
    }
  };

  const styles = colorClasses[color];
  const progressPercentage = (completedExams / totalExams) * 100;

  return (
    <Card className={`transition-all duration-200 hover:shadow-xl hover:-translate-y-2 ${styles.border} border-2 dark:bg-gray-800`}>
      <CardHeader className={`${styles.headerBg} rounded-t-lg`}>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className={`text-xl ${styles.icon}`}>{title}</CardTitle>
            <CardDescription className="mt-1">{description}</CardDescription>
          </div>
          <Badge className={styles.badge}>
            {completedExams}/{totalExams} Exams
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="pt-6 space-y-4">
        {/* Progress Section */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Progress</span>
            <span className="text-sm font-bold text-gray-900 dark:text-gray-100">{Math.round(progressPercentage)}%</span>
          </div>
          <Progress value={progressPercentage} className="h-3 bg-gray-200 dark:bg-gray-700">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${styles.progress}`}
              style={{ width: `${progressPercentage}%` }}
            />
          </Progress>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3 text-center">
            <div className="flex items-center justify-center mb-1">
              <Trophy className={`w-4 h-4 ${styles.icon} mr-1`} />
            </div>
            <div className="text-lg font-bold text-gray-900 dark:text-gray-100">{averageScore}%</div>
            <div className="text-xs text-gray-600 dark:text-gray-400">Avg Score</div>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3 text-center">
            <div className="flex items-center justify-center mb-1">
              <Clock className={`w-4 h-4 ${styles.icon} mr-1`} />
            </div>
            <div className="text-lg font-bold text-gray-900 dark:text-gray-100">{timeSpent}</div>
            <div className="text-xs text-gray-600 dark:text-gray-400">Time Spent</div>
          </div>
        </div>

        {/* Achievement Indicators */}
        <div className="flex gap-2">
          {averageScore >= 90 && (
            <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300 text-xs">⭐ High Performer</Badge>
          )}
          {completedExams >= 5 && (
            <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-300 text-xs">🔥 Active Learner</Badge>
          )}
          {progressPercentage === 100 && (
            <Badge className="bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300 text-xs">✅ Completed</Badge>
          )}
        </div>

        {/* Action Button */}
        <Button 
          onClick={onStartPractice}
          className={`w-full ${styles.button} text-white font-medium py-3`}
        >
          <Play className="w-4 h-4 mr-2" />
          Start Practice Exam
        </Button>
      </CardContent>
    </Card>
  );
}