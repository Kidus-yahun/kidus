import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { SubjectCard } from './SubjectCard';
import { GradeCard } from './GradeCard';
import { PracticeExamCard } from './PracticeExamCard';
import { AnalyticsPanel } from './AnalyticsPanel';
import { FileText, FlaskConical, Users, StickyNote, Play } from 'lucide-react';

export function Dashboard() {
  // Practice Exam data for the main subjects
  const practiceExamData = [
    {
      title: "Mathematics",
      description: "Algebra, Calculus, Statistics",
      totalExams: 15,
      completedExams: 12,
      averageScore: 92,
      timeSpent: "24h",
      color: 'green' as const
    },
    {
      title: "English",
      description: "Literature, Grammar, Writing",
      totalExams: 12,
      completedExams: 8,
      averageScore: 85,
      timeSpent: "18h",
      color: 'blue' as const
    },
    {
      title: "Physics",
      description: "Mechanics, Waves, Electricity",
      totalExams: 10,
      completedExams: 6,
      averageScore: 78,
      timeSpent: "16h",
      color: 'red' as const
    },
    {
      title: "Biology",
      description: "Cell Biology, Genetics, Ecology",
      totalExams: 9,
      completedExams: 7,
      averageScore: 88,
      timeSpent: "14h",
      color: 'yellow' as const
    }
  ];

  const handleStartPractice = (subject: string) => {
    console.log(`Starting practice exam for ${subject}`);
    // Here you would implement the navigation to practice exam
  };

  const examPapers = [
    {
      title: "Mathematics",
      description: "Algebra, Calculus, Statistics",
      examPapers: 15,
      color: 'green' as const
    },
    {
      title: "English",
      description: "Literature, Grammar, Writing",
      examPapers: 12,
      color: 'blue' as const
    },
    {
      title: "Physics",
      description: "Mechanics, Waves, Electricity",
      examPapers: 10,
      color: 'red' as const
    },
    {
      title: "Chemistry",
      description: "Organic, Inorganic, Physical",
      examPapers: 11,
      color: 'yellow' as const
    },
    {
      title: "Biology",
      description: "Cell Biology, Genetics, Ecology",
      examPapers: 9,
      color: 'green' as const
    },
    {
      title: "History",
      description: "World History, Ethiopian History",
      examPapers: 8,
      color: 'red' as const
    },
    {
      title: "Geography",
      description: "Physical, Human, Regional",
      examPapers: 7,
      color: 'blue' as const
    },
    {
      title: "Civics",
      description: "Government, Law, Rights",
      examPapers: 6,
      color: 'yellow' as const
    },
    {
      title: "Economics",
      description: "Micro, Macro, Development",
      examPapers: 8,
      color: 'green' as const
    }
  ];

  const naturalScienceBooks = [
    {
      title: "Mathematics",
      description: "Advanced Mathematics for Grade 12",
      bookChapters: 18,
      color: 'green' as const
    },
    {
      title: "Physics",
      description: "Comprehensive Physics Textbook",
      bookChapters: 16,
      color: 'red' as const
    },
    {
      title: "Chemistry",
      description: "Modern Chemistry Concepts",
      bookChapters: 15,
      color: 'yellow' as const
    },
    {
      title: "Biology",
      description: "Life Sciences and Biology",
      bookChapters: 14,
      color: 'green' as const
    },
    {
      title: "English",
      description: "Language and Literature",
      bookChapters: 12,
      color: 'blue' as const
    }
  ];

  const socialScienceBooks = [
    {
      title: "History",
      description: "World and Ethiopian History",
      bookChapters: 16,
      color: 'red' as const
    },
    {
      title: "Civics & Ethics",
      description: "Citizenship and Moral Education",
      bookChapters: 12,
      color: 'yellow' as const
    },
    {
      title: "Geography",
      description: "Physical and Human Geography",
      bookChapters: 14,
      color: 'blue' as const
    },
    {
      title: "Economics",
      description: "Principles of Economics",
      bookChapters: 13,
      color: 'green' as const
    },
    {
      title: "Mathematics",
      description: "Applied Mathematics",
      bookChapters: 15,
      color: 'green' as const
    },
    {
      title: "English",
      description: "Communication Skills",
      bookChapters: 10,
      color: 'blue' as const
    }
  ];

  const shortNotes = [
    {
      grade: "Grade 9",
      description: "Foundation concepts and introductory topics",
      notesCount: 45,
      subjects: ["Math", "English", "Biology", "Chemistry", "Physics", "History", "Geography"],
      color: 'green' as const
    },
    {
      grade: "Grade 10",
      description: "Intermediate level concepts and problem solving",
      notesCount: 52,
      subjects: ["Math", "English", "Biology", "Chemistry", "Physics", "History", "Geography", "Civics"],
      color: 'blue' as const
    },
    {
      grade: "Grade 11",
      description: "Advanced preparation and specialization",
      notesCount: 67,
      subjects: ["Math", "English", "Biology", "Chemistry", "Physics", "History", "Geography", "Economics"],
      color: 'yellow' as const
    },
    {
      grade: "Grade 12",
      description: "University entrance exam preparation",
      notesCount: 78,
      subjects: ["Math", "English", "Biology", "Chemistry", "Physics", "History", "Geography", "Economics", "Civics"],
      color: 'red' as const
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-green-600 via-yellow-500 to-red-600 rounded-lg p-6 text-white">
            <h1 className="text-3xl font-bold mb-2">Welcome to Your Study Dashboard</h1>
            <p className="text-green-100">Access all your Grade 12 study materials, exam papers, and textbooks in one place</p>
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="practice" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8 bg-white dark:bg-gray-800">
            <TabsTrigger value="practice" className="flex items-center gap-2 dark:data-[state=active]:bg-gray-700">
              <Play className="w-4 h-4" />
              Practice Exams
            </TabsTrigger>
            <TabsTrigger value="exams" className="flex items-center gap-2 dark:data-[state=active]:bg-gray-700">
              <FileText className="w-4 h-4" />
              Past Papers
            </TabsTrigger>
            <TabsTrigger value="natural" className="flex items-center gap-2 dark:data-[state=active]:bg-gray-700">
              <FlaskConical className="w-4 h-4" />
              Natural Science
            </TabsTrigger>
            <TabsTrigger value="social" className="flex items-center gap-2 dark:data-[state=active]:bg-gray-700">
              <Users className="w-4 h-4" />
              Social Science
            </TabsTrigger>
            <TabsTrigger value="notes" className="flex items-center gap-2 dark:data-[state=active]:bg-gray-700">
              <StickyNote className="w-4 h-4" />
              Short Notes
            </TabsTrigger>
          </TabsList>

          {/* Practice Exams Tab */}
          <TabsContent value="practice">
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">Practice Exams</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-6">Take practice exams, track your progress, and improve your scores</p>
              </div>
              
              {/* Practice Exam Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
                {practiceExamData.map((subject, index) => (
                  <PracticeExamCard
                    key={index}
                    title={subject.title}
                    description={subject.description}
                    totalExams={subject.totalExams}
                    completedExams={subject.completedExams}
                    averageScore={subject.averageScore}
                    timeSpent={subject.timeSpent}
                    color={subject.color}
                    onStartPractice={() => handleStartPractice(subject.title)}
                  />
                ))}
              </div>

              {/* Analytics Panel */}
              <div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-6">Your Performance Analytics</h3>
                <AnalyticsPanel />
              </div>
            </div>
          </TabsContent>

          {/* Past Exam Papers */}
          <TabsContent value="exams">
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">Past Exam Papers</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-6">Practice with previous years' examination papers across all subjects</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {examPapers.map((subject, index) => (
                  <SubjectCard
                    key={index}
                    title={subject.title}
                    description={subject.description}
                    examPapers={subject.examPapers}
                    color={subject.color}
                    type="exam"
                  />
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Natural Science Books */}
          <TabsContent value="natural">
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">Natural Science Stream</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-6">Comprehensive textbooks for Mathematics, Physics, Chemistry, Biology, and English</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {naturalScienceBooks.map((book, index) => (
                  <SubjectCard
                    key={index}
                    title={book.title}
                    description={book.description}
                    bookChapters={book.bookChapters}
                    color={book.color}
                    type="book"
                  />
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Social Science Books */}
          <TabsContent value="social">
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">Social Science Stream</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-6">Essential textbooks for History, Civics, Geography, Economics, Mathematics, and English</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {socialScienceBooks.map((book, index) => (
                  <SubjectCard
                    key={index}
                    title={book.title}
                    description={book.description}
                    bookChapters={book.bookChapters}
                    color={book.color}
                    type="book"
                  />
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Short Notes */}
          <TabsContent value="notes">
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">Short Notes (Grade 9-12)</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-6">Quick reference notes and key concepts for all grades and subjects</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {shortNotes.map((grade, index) => (
                  <GradeCard
                    key={index}
                    grade={grade.grade}
                    description={grade.description}
                    notesCount={grade.notesCount}
                    subjects={grade.subjects}
                    color={grade.color}
                  />
                ))}
              </div>
              
              {/* Additional Info Section */}
              <div className="mt-8 bg-gradient-to-r from-green-50 via-yellow-50 to-red-50 dark:from-green-900/20 dark:via-yellow-900/20 dark:to-red-900/20 rounded-lg p-6 border border-green-200 dark:border-green-800">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">What's in Short Notes?</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-green-100 dark:bg-green-900/50 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <StickyNote className="w-6 h-6 text-green-600 dark:text-green-400" />
                    </div>
                    <h4 className="font-medium text-gray-900 dark:text-gray-100">Key Concepts</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Essential theories and definitions</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/50 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <FileText className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
                    </div>
                    <h4 className="font-medium text-gray-900 dark:text-gray-100">Formulas & Examples</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Important formulas with solved examples</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-red-100 dark:bg-red-900/50 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <FlaskConical className="w-6 h-6 text-red-600 dark:text-red-400" />
                    </div>
                    <h4 className="font-medium text-gray-900 dark:text-gray-100">Quick Review</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Perfect for last-minute revision</p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Quick Stats */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border-l-4 border-green-500">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Practice Exams</h3>
            <p className="text-3xl font-bold text-green-600 dark:text-green-400">33</p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Completed this month</p>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border-l-4 border-blue-500">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Avg Score</h3>
            <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">87%</p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Across all subjects</p>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border-l-4 border-yellow-500">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Study Time</h3>
            <p className="text-3xl font-bold text-yellow-600 dark:text-yellow-400">72h</p>
            <p className="text-sm text-gray-600 dark:text-gray-400">This month</p>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border-l-4 border-red-500">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Study Streak</h3>
            <p className="text-3xl font-bold text-red-600 dark:text-red-400">12</p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Days in a row</p>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border-l-4 border-purple-500">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Short Notes</h3>
            <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">242</p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Available notes</p>
          </div>
        </div>
      </div>
    </div>
  );
}