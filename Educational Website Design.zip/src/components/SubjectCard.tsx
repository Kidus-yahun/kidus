import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { BookOpen, FileText, Download } from 'lucide-react';

interface SubjectCardProps {
  title: string;
  description: string;
  examPapers?: number;
  bookChapters?: number;
  color: 'green' | 'yellow' | 'red' | 'blue';
  type: 'exam' | 'book';
}

export function SubjectCard({ title, description, examPapers, bookChapters, color, type }: SubjectCardProps) {
  const colorClasses = {
    green: {
      border: 'border-green-200 dark:border-green-800',
      headerBg: 'bg-green-50 dark:bg-green-900/30',
      icon: 'text-green-600 dark:text-green-400',
      button: 'bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600',
      badge: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300'
    },
    yellow: {
      border: 'border-yellow-200 dark:border-yellow-800',
      headerBg: 'bg-yellow-50 dark:bg-yellow-900/30',
      icon: 'text-yellow-600 dark:text-yellow-400',
      button: 'bg-yellow-600 hover:bg-yellow-700 dark:bg-yellow-700 dark:hover:bg-yellow-600',
      badge: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300'
    },
    red: {
      border: 'border-red-200 dark:border-red-800',
      headerBg: 'bg-red-50 dark:bg-red-900/30',
      icon: 'text-red-600 dark:text-red-400',
      button: 'bg-red-600 hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600',
      badge: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300'
    },
    blue: {
      border: 'border-blue-200 dark:border-blue-800',
      headerBg: 'bg-blue-50 dark:bg-blue-900/30',
      icon: 'text-blue-600 dark:text-blue-400',
      button: 'bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600',
      badge: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300'
    }
  };

  const styles = colorClasses[color];

  return (
    <Card className={`transition-all duration-200 hover:shadow-lg hover:-translate-y-1 ${styles.border} border-2 dark:bg-gray-800`}>
      <CardHeader className={`${styles.headerBg} rounded-t-lg`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {type === 'exam' ? (
              <FileText className={`w-6 h-6 ${styles.icon}`} />
            ) : (
              <BookOpen className={`w-6 h-6 ${styles.icon}`} />
            )}
            <div>
              <CardTitle className="text-lg">{title}</CardTitle>
              <CardDescription className="mt-1">{description}</CardDescription>
            </div>
          </div>
          {type === 'exam' && examPapers && (
            <Badge className={styles.badge}>
              {examPapers} Papers
            </Badge>
          )}
          {type === 'book' && bookChapters && (
            <Badge className={styles.badge}>
              {bookChapters} Chapters
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-3">
          {type === 'exam' && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Available Resources:</p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs bg-gray-100 dark:bg-gray-700 dark:text-gray-300 px-2 py-1 rounded">2019-2023 Papers</span>
                <span className="text-xs bg-gray-100 dark:bg-gray-700 dark:text-gray-300 px-2 py-1 rounded">Answer Keys</span>
                <span className="text-xs bg-gray-100 dark:bg-gray-700 dark:text-gray-300 px-2 py-1 rounded">Mark Schemes</span>
              </div>
            </div>
          )}
          {type === 'book' && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Study Materials:</p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs bg-gray-100 dark:bg-gray-700 dark:text-gray-300 px-2 py-1 rounded">Textbook PDF</span>
                <span className="text-xs bg-gray-100 dark:bg-gray-700 dark:text-gray-300 px-2 py-1 rounded">Practice Problems</span>
                <span className="text-xs bg-gray-100 dark:bg-gray-700 dark:text-gray-300 px-2 py-1 rounded">Chapter Summaries</span>
              </div>
            </div>
          )}
          <Button className={`w-full ${styles.button} text-white`}>
            <Download className="w-4 h-4 mr-2" />
            {type === 'exam' ? 'Access Exam Papers' : 'Open Study Materials'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}